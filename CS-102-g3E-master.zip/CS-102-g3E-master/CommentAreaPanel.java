import javax.swing.*;

public class CommentAreaPanel extends JPanel
{
    //Still under Development
}
